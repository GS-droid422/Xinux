package com.xinux.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int MATCH = -1, WRAP = -2;
    FrameLayout root;
    ScrollView startMenu;
    TextView clock;
    Handler handler = new Handler();

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF0A3D91, 0xFF1E88E5, 0xFF00B0FF}));
        root.setOnClickListener(v -> startMenu.setVisibility(View.GONE));

        LinearLayout desk = new LinearLayout(this);
        desk.setOrientation(LinearLayout.VERTICAL);
        desk.setPadding(dp(12), dp(12), 0, 0);
        desk.addView(icon("🌐", "Edge", v -> openEdge()));
        desk.addView(icon("📁", "Arquivos", v -> openFiles()));
        root.addView(desk, new FrameLayout.LayoutParams(WRAP, WRAP));

        buildStartMenu();
        buildTaskbar();
        setContentView(root);
    }

    TextView label(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(sp);
        return t;
    }

    View icon(String emoji, String name, View.OnClickListener l) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(8), dp(8), dp(8), dp(8));
        TextView e = label(emoji, 32);
        e.setGravity(Gravity.CENTER);
        TextView n = label(name, 12);
        n.setGravity(Gravity.CENTER);
        c.addView(e);
        c.addView(n);
        c.setOnClickListener(l);
        c.setLayoutParams(new LinearLayout.LayoutParams(dp(84), WRAP));
        return c;
    }

    void buildTaskbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xEE101010);

        TextView start = label("🟦🟦", 22);
        start.setGravity(Gravity.CENTER);
        start.setPadding(dp(14), 0, dp(14), 0);
        start.setOnClickListener(v -> startMenu.setVisibility(
                startMenu.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));

        TextView edge = label("🌐", 22);
        edge.setGravity(Gravity.CENTER);
        edge.setPadding(dp(14), 0, dp(14), 0);
        edge.setOnClickListener(v -> openEdge());

        clock = label("", 12);
        clock.setGravity(Gravity.CENTER);
        clock.setPadding(dp(12), 0, dp(12), 0);

        bar.addView(start, new LinearLayout.LayoutParams(WRAP, MATCH));
        bar.addView(edge, new LinearLayout.LayoutParams(WRAP, MATCH));
        bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        bar.addView(clock, new LinearLayout.LayoutParams(WRAP, MATCH));
        root.addView(bar, new FrameLayout.LayoutParams(MATCH, dp(48), Gravity.BOTTOM));
        tick();
    }

    void tick() {
        clock.setText(new SimpleDateFormat("HH:mm\ndd/MM/yyyy", Locale.getDefault()).format(new Date()));
        handler.postDelayed(this::tick, 20000);
    }

    void buildStartMenu() {
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(8), dp(8), dp(8), dp(8));
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(q, 0);
        Collections.sort(apps, new ResolveInfo.DisplayNameComparator(pm));
        for (ResolveInfo ri : apps) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(8), dp(8), dp(8));
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(ri.loadIcon(pm));
            row.addView(iv, new LinearLayout.LayoutParams(dp(32), dp(32)));
            TextView t = label(ri.loadLabel(pm).toString(), 15);
            t.setPadding(dp(12), 0, 0, 0);
            row.addView(t);
            Intent li = pm.getLaunchIntentForPackage(pkg);
            row.setOnClickListener(v -> {
                startMenu.setVisibility(View.GONE);
                if (li != null) startActivity(li);
            });
            list.addView(row);
        }
        startMenu = new ScrollView(this);
        startMenu.setBackgroundColor(0xEE202020);
        startMenu.addView(list);
        startMenu.setVisibility(View.GONE);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(320), dp(440), Gravity.BOTTOM | Gravity.START);
        lp.bottomMargin = dp(48);
        root.addView(startMenu, lp);
    }

    void openEdge() {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.microsoft.emmx");
        try {
            if (i == null) i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.microsoft.emmx"));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.microsoft.emmx")));
            } catch (Exception ignored) { }
        }
    }

    void openFiles() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("*/*");
            startActivity(i);
        } catch (Exception ignored) { }
    }

    @Override
    public void onBackPressed() { startMenu.setVisibility(View.GONE); }
}
